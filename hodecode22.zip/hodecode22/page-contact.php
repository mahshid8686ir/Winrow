  <?php get_header() ?>
    <main class="mx-auto max-w-120 bg-white rounded-xl my-20 p-5">
      <?php
      the_content();
      ?>
    </main>
  <?php get_footer()
  ?>

  
  
  

